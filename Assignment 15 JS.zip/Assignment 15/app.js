// ------------Chapter 1-----------


// Question 1 
// alert("Hello World")

// Question  2
// alert("Error! Please enter a valid password.")

// Question 3
// alert("Welcome to JS Land... \n  Happy Coding!")

// Question 4
// alert("Welcome to JS Land...")
// alert("Happy Coding!")

// Question 5
// console.log("Hello... I can run JS through my web browser's console");

// Question 7
// Done in index.html file



// ------------Chapter 2-----------


// Question 1 
// var username=jazib;

// Question 2 
// var myname="jazib";

// Question 3
// var message;
// message="Hello World";
// alert (message);

// Question 4
// var studentName="Syed Jazib Hussain Rizvi";
// alert(studentName)

// var studentAge="21 years old";
// alert(studentAge)

// var studentFuturePlan="Mern Stack Developer";
// alert(studentFuturePlan)

// Question 5
//  var food="PIZZA\nPIZZ\nPIZ\nPI\nP";
//  alert(food)

// Question 6
//  var email="jazibhussain110@gmail.com";
//  alert("My email address is " +email)

// Question 7
//  var book="A smarter way to learn JavaScript";
//  alert("I am trying to learn from the book " +book)

// Question 8
// document.write("Yah ! I can write HTML content through JavaScript");

// Question 9
//  var design="“▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬”";
//  alert(design)


// ------------Chapter 3-----------


// Question 1
// var age="I am 21 years old";
// alert(age)

// Question 2
// var numberOfvisits ="You have visited this site 14 times";
// alert(numberOfvisits);

// Question 3
// var birthYear = "My Birth Year Is 2000 </br> Data Type OF My Declared Variable Is Number";
// document.write(birthYear);

// Question 4
// var VisitorsName="Jazib";
// var Quantity="5";
// var ProductTitle="T-shirt";
// document.write(VisitorsName + " " + "ordered" + " "+Quantity +" "+ProductTitle +"(s) on XYZ Clothing store");


// ------------Chapter 4-----------


// Question 1
// var variable1 = "Syed" + " ",
//     variable2 = "Jazib" + " ",
//     variable3 = 21;
// alert (variable1+variable2+variable3);

// Question 2
//Legal Variable Names
// var a1="jazib"
// var $a="jazib"
// var _a="jazib"
// var topScore = 100;
// var total = cost + profit;
//Illegal Variable Names
// var 1a="jazib"
// var #a="jazib"
// var %jaz;
// var ,lastname = "jaz";
// var _9w;

// Question 3
// document.write("<h1>" + "Rules for naming JS variables" + "</h1>" + "<br/>");
// document.write( "Variable names can only contain" + " " + "," + " " + "numbers" + "," + " " + "$ and" + " " + " _" + " " + "." + " " + "For example :"+  " " + "$my" + " " + "_ 1st Variable" + "<br/>" + "Variables must begin with a letter, $ or _ . For Example: $name, _ name or name" + "</br>" + "Variable names are case" + " " + "sensitive" + "</br>" + "Variable names should not be JS" + " " + "Keywords" + "</p>");


// ------------Chapter 5-----------


// Question 1
// var a = 3;
// var b = 5;
// var c = a + b;
// document.write( "Sum of" + "  " + a + " " + "and" + " " + b + " " + "is" + " " + c );

// Question 2
// for subtraction
// var a = 3;
// var b = 5;
// var c = a - b;
// document.write("Subtraction of" + "  " + a + " " + "and" + " " + b + " " + "is" + " " + c);

//for multiplication
// var a = 3;
// var b = 5;
// var c = a * b;
// document.write("Multiplication of" + "  " + a + " " + "and" + " " + b + " " + "is" + " " + c);

//for  division
// var a = 3;
// var b = 5;
// var c = a / b;
// document.write("Division of" + "  " + a + " " + "and" + " " + b + " " + "is" + " " + c);

//for  modulus
// var a = 3;
// var b = 5;
// var c = a % b;
// document.write("Modulus of" + "  " + a + " " + "and" + " " + b + " " + "is" + " " + c);

// Question 3
// var a;
// document.write("<p style='font-size: 20px; font-weight: 500;'>" + "Value after variable declaration is" + "  " );
// document.write("<p style='font-size: 20px; font-weight: 500;'>" + "Initial Value:" + "  "  +  " ");
// document.write("<p style='font-size: 20px; font-weight: 500;'>" + "Value after increment is:" + "  " );
// document.write("<p style='font-size: 20px; font-weight: 500;'>" + "Value after addition is:" + "  " );
// document.write("<p style='font-size: 20px; font-weight: 500;'>" + "Value after decrement is:" + "  ");
// document.write("<p style='font-size: 20px; font-weight: 500;'>" + "The remainder is:" + "  ");

// Question 4
// var ticketPrice = 600;
// var b = 5;
// var c = ticketPrice * b;
// document.write("Total cost to buy" + "  " + b + " " + "tickets to a movie is" + " " + c + "PKR");

// Question 5
// var x = 4, i;
// for(i=1;i<=10;i++)
// document.write("<h4>"  + "4x" + i + "=" + i*x + "</h4>");


// Question 6
// var celSius=30, fahreNheit=86, conversion1, conversion2;
// conversion1=(fahreNheit-32)*5/9;
// conversion2=(celSius*9/5)+32
// document.write("Fahrenheit Is:"+ " " + conversion1 + "<br/>" + "Celsius Is:" + " " + conversion2);


// Question 7
// var  priceOfitem1 = 650,  priceOfitem2 = 100, quantity1 = 3, quantity2 = 7, shippingCharges = 100, 
// totalCost =priceOfitem1*quantity1+priceOfitem2+shippingCharges*quantity2;
// document.write("<h1>"+ "Shopiing Cart " + "</h1>" + "<br/>");
// document.write("<p style='font-size: 20px; font-weight: 500;'>" + " Price of item 1 is" + " " + priceOfitem1 + "<br/>" + "Quantity of item 1 is" + " " + quantity1 + "<br/>" + "Price of item 2 is" + " " + priceOfitem2 + "<br/>" + "Quantity of item 2 is" + " " + quantity2 + "<br/>" + " Sipping Charges" + " " + shippingCharges + "<br/>" +  "<br/>" + "Total cost of your ordered is" + " " + totalCost + "</p>");



// Question 8
// document.write("<h1>"+ "Marks Sheets " + "</h1>" + "<br/>");
// var total = "980", ob = "804", per;
// per=ob*100/total;
// document.write("<p style='font-size: 20px; font-weight: 500;'>" + "Total Marks:" + " " + total + "<br/>" + "Marks Obtained:" + " " + ob + "<br/>" + "Percentage" + " " + per + "</p>");



// Question 9
// var usDollars = 104.80*10, saudiRiyals = 25*28, pakistaniRupee;
//  pakistaniRupee= usDollars+saudiRiyals;
// document.write("<h1>"+ "Currency In PKR" + "</h1>" + "<br/>");
// document.write("<p style='font-size: 20px; font-weight: 500;'>" + "Total Currency in PKR:" + " " + pakistaniRupee + "</p>");


// Question 10
// a=5, b=2, c=a*b, d=c/a;
// document.write("<p style='font-size: 20px; font-weight: 600;'>" + "a. Add" + " " + a + "<br/>" + "b. Multiply by" + " " + c + "<br/>" + "c. Divide the result by" + " " + d + "</p>");


// Question 11
// document.write("<h1 style='font-size: 38px; font-weight: 900;'>" + "Age Calculator" + "</h1>" + "<br/>");
// var currentYear = 2020, birthYear = 1999, age=currentYear-birthYear;
// document.write("<p style='font-size: 22px; font-weight: 500;'>" + "Current Year: " + " " + currentYear + "<br/>" + "Birth Year:" + " " + birthYear + "<br/>" + "Your Age Is:"+ " " + age);



// Question 12
// var area, r, pi = 3.142, coc;
// r=parseInt(prompt("Enter The Radius"));
// area=pi*r*r;
// coc=2*pi*r;
// document.write("<h1 style='font-size: 38px; font-weight: 900;'>" + "The Geometrizer" + "</h1>" + "<br/>");
// document.write("<p style='font-size: 22px; font-weight: 500;'>" + "Radius of a circle: " + " " + r + "<br/>" + "The circumference is:" + " " + coc +  "<br/>" + "The area is:" + " " + area + "</p>");



// Question 13
// var favoriteSnack="Potato Chips", currentAge=21,  maximumAge=70,  amountPerday=2, totalForrest;
// totalForrest = currentAge+maximumAge*amountPerday;
// document.write("<h1 style='font-size: 38px; font-weight: 900;'>" + "The Lifetime Supply Calculator" + "</h1>" + "<br/>");
// document.write("<p style='font-size: 20px; font-weight: 500;'>" + "Favourite Snack:"  + " " + favoriteSnack + "<br/>" + "Current Age:" + " " + currentAge + "<br/>" + "Extimated Maximum Age:"+ " " + maximumAge + "<br/>" + "Amount Of Snacks Per Day" + " " + amountPerday + "<br/>" + "You will need" + " " + totalForrest + " " + "to last you until the ripe old age of" + "  " + maximumAge + "</p>" );


// ------------Chapter 6-9 -----------

//Question 1
// var a = 10;
// document.write("Result:" + "<br/>" + "The value of a is:"+ " " + a + "<br/>" + "..................................." + "<br/><br/>");
// var a= ++a;
// document.write("The value of ++a is:" + a + "<br/>" + "Now the value of a is:"+ " " + a + "<br/><br/>");
// var a= ++a;
// var b = a++;
// document.write("The value of a++ is:" + a + "<br/>" + "Now the value of a is:"+ " " + a + "<br/><br/>");

//Question 2
// var a = 2, b = 1;
// var result = --a - --b + ++b + b--;
// document.write("a is" + " " + a + "<br/>" + "b is" + " " + b + "<br/>" + "result is" + " " + result);



//Question 3
//  var a=(prompt("Enter Your Name"));
// alert("Welcome:" + "  " + a);



//Question 5
// var x, i;
// var x=(prompt("Enter The Number.."));
// for(i=1;i<=10;i++)
// document.write("<h3>"  + x + "x" + i + "=" + x*i + "</h3>");


// ------------Chapter 10-11 -----------


//Question 1
// var k = "karachi"; var cityName;
// cityName = (prompt("Enter Your City name"));
// if (cityName == k) {
//     alert("Welcome to city of lights");
// }

// else {
//     alert(cityName);
// }



//Question 2
// var maLe = "male", feMale = "female";
// var inputUser = (prompt("Enter Your Gender"));
// if (inputUser == maLe) {
//     alert("Good Morning Sir.");
// }
// else if (inputUser == feMale) {
//     alert("Good Morning Ma'am.");
// }



//Question 3
// yellow = "yellow", green = "green", red = "red";
// var colorRoad = (prompt("Input Color Of Road Traffic Signal"));

// if (red = colorRoad) {
//     document.write("<table align='center'><tr><td>" + colorRoad + "</td><td>Must Stop</td></tr></table>");
// }

// else if (yellow = colorRoad) {
//     document.write("<table align='center'><tr><td>" + colorRoad + "</td><td>Ready To Move</td></tr></table>");
// }

// else if (colorRoad = green) {
//     document.write("<table align='center'><tr><td>" + colorRoad + "</td><td>Move Now</td></tr></table>");
// }



//Question 4 
// var fuelLess = 0.25;
// var remainingFuel = (prompt("Input Remaining Fuel In car (In Litres)"));
// if (remainingFuel < fuelLess) {
//     alert("Please refill the fuel in your car");
// }

